package ec.edu.espe.stadium.controller;

import ec.edu.espe.stadium.model.Stadium;
import java.util.ArrayList;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 */
public class ViewController {
    StadiumController stadiumController;
    
    private static ViewController instance;
    
    private ViewController() {
        this.stadiumController = StadiumController.getInstance();
    }
    
    public synchronized static ViewController getInstance (){
        if (instance != null){
        
        } 
        else {
            instance = new ViewController();
        }
        
        return instance;
    }
    
    public void displayTable(JTable tbl){
        ArrayList<Stadium> stadiums = stadiumController.obtainAll();
        
        DefaultTableModel inventoryTableModel = writeTable(stadiums, tbl);
        tbl.setModel(inventoryTableModel);
        tbl.setDefaultEditor(Object.class, null);
    }
    
    public static DefaultTableModel writeTable(ArrayList<Stadium> stadiums, JTable tbl) {
        DefaultTableModel inventoryTableModel = new DefaultTableModel();
        
        Object[] stadiumData = new Object[tbl.getColumnCount()];
        
        String[] header = {"ID","Name","Capacity", "BoxOfMoney"};
        
        inventoryTableModel.setColumnIdentifiers(header);
        
        for(Stadium stadium: stadiums){
            
            stadiumData[0] = stadium.getId();
            stadiumData[1]= stadium.getName();
            stadiumData[2] = stadium.getCapacity();
            stadiumData[3] = stadium.getBoxmoney();

            
            inventoryTableModel.addRow(stadiumData);
            
        }
        
        return inventoryTableModel;
    }
    
    public void displayTable1(JTable tbl){
        ArrayList<Stadium> stadiums = stadiumController.obtainAll();
        
        DefaultTableModel inventoryTableModel = writeTable(stadiums, tbl);
        tbl.setModel(inventoryTableModel);
        tbl.setDefaultEditor(Object.class, null);
    }
        
    public static DefaultTableModel writeTable1(ArrayList<Stadium> stadiums, JTable tbl) {
        DefaultTableModel inventoryTableModel = new DefaultTableModel();
        
        Object[] stadiumData = new Object[tbl.getColumnCount()];
        
        String[] header = {"ID","Name","Capacity"};
        
        inventoryTableModel.setColumnIdentifiers(header);
        
        for(Stadium stadium: stadiums){
            
            stadiumData[0] = stadium.getId();
            stadiumData[1]= stadium.getName();
            stadiumData[2] = stadium.getCapacity();
            
            inventoryTableModel.addRow(stadiumData);
            
        }
        
        return inventoryTableModel;
    }
    
    
}
