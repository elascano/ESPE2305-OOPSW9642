package ec.edu.espe.stadium.controller;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import ec.edu.espe.stadium.utils.DatabaseManager;
import org.bson.Document;

/**
 *
 * @author Anthony Morales, The_FAMSE
 */
public class DatabaseController {
    String clientURL;
    String databaseName;
    MongoDatabase database;

    private static DatabaseController instance;
    
    private DatabaseController() {
        this.clientURL = "mongodb+srv://anthonymorales:anthonymorales@cluster0.nngqbpt.mongodb.net/";
        this.databaseName = "Exam";
        this.database = DatabaseManager.connectToDatabase(clientURL, databaseName);
    }
    
    public synchronized static DatabaseController getInstance (){
        if (instance != null){
        
        } 
        else {
            instance = new DatabaseController();
        }
        
        return instance;
    }

    @Override
    protected Object clone() throws CloneNotSupportedException {
        throw new CloneNotSupportedException();
    }
    
    public MongoCollection changeCollection(String collectionName){
        MongoCollection <Document> collection = DatabaseManager.connectToCollection(database, collectionName);
        return collection;
    }
}
