package ec.edu.espe.stadium.model;

import java.util.HashMap;

/**
 *
 * @author Anthony Morales, The_FAMSE
 */
public interface Map {
        public HashMap<Object, Object> getData();
}
