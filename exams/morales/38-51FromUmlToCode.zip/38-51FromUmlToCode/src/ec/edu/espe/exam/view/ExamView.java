/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ec.edu.espe.exam.view;

import ec.edu.espe.exam.model.B;
import ec.edu.espe.exam.model.C;
import ec.edu.espe.exam.model.D;
import ec.edu.espe.exam.model.E;

/**
 *
 * @author Anthony Morales, The_FAMSE
 */
public class ExamView {
    public static void main(String[] args) {
        B b = new B();
        C c = new C();
        D d = new D();
        E e = new E();
        c.print(e);
    }
}
