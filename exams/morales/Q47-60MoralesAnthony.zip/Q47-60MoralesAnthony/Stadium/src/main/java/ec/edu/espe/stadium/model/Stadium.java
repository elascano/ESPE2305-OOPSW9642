package ec.edu.espe.stadium.model;

import java.util.HashMap;

/**
 *
 * @author Joan Cobeña, KillChain, DCCO-ESPE
 */
public class Stadium implements Map{
    
    private HashMap<Object, Object> data;
    private int id;
    String name;
    private double capacity;
    private double boxmoney;
    
    public Stadium() {
    
    }
    
    public Stadium(int id, String name, double capacity) {
        data = new HashMap<Object, Object>();
        data.put("id", id);
        data.put("name", name);
        data.put("capacity", capacity);
        
        this.id = id;
        this.name = name;
        this.capacity = capacity; 
    }
    
    public Stadium(int id, String name, double capacity, double boxmoney) {
        data = new HashMap<Object, Object>();
        data.put("id", id);
        data.put("name", name);
        data.put("capacity", capacity);
        data.put("boxmoney", boxmoney);
        
        this.id = id;
        this.name = name;
        this.capacity = capacity; 
        this.boxmoney = boxmoney;
    }
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getCapacity() {
        return capacity;
    }

    public void setCapacity(double capacity) {
        this.capacity = capacity;
    }

    public double getBoxmoney() {
        return boxmoney;
    }

    public void setBoxmoney(double boxmoney) {
        this.boxmoney = boxmoney;
    }
    
    @Override
    public HashMap<Object, Object> getData() {
        return data;
    }
   
    
}
