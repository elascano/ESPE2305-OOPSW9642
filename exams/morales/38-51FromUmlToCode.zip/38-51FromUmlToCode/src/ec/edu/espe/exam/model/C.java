
package ec.edu.espe.exam.model;

/**
 *
 * @author Anthony Morales, The_FAMSE
 */
public class C{
    C c;
    private E eValue;

    public void print(E e) {
        System.out.println("This is a E value: " + e);
    }

    @Override
    public String toString() {
        return "C{" + "eValue=" + eValue + '}';
    }

    /**
     * @return the eValue
     */
    public E getEValue() {
        return eValue;
    }

    /**
     * @param eValue the eValue to set
     */
    public void setEValue(E eValue) {
        this.eValue = eValue;
    }

    public void print() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
