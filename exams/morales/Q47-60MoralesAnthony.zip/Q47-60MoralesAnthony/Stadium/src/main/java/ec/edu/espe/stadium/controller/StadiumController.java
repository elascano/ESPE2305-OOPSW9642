
package ec.edu.espe.stadium.controller;
import com.mongodb.client.MongoCollection;
import ec.edu.espe.stadium.model.Stadium;
import ec.edu.espe.stadium.utils.DatabaseManager;
import java.util.ArrayList;
import java.util.HashMap;

/**
 *
 */
public class StadiumController {
    DatabaseController database;
    MongoCollection collection;
    
    private static StadiumController instance;
    
    private StadiumController() {
        this.database = DatabaseController.getInstance();
        this.collection = DatabaseController.getInstance().changeCollection("Stadium");
    }
    
    public synchronized static StadiumController getInstance (){
        if (instance != null){
        
        } 
        else {
            instance = new StadiumController();
        }
        
        return instance;
    }

    @Override
    protected Object clone() throws CloneNotSupportedException {
        throw new CloneNotSupportedException();
    }
    
    public void save(Stadium stadium){
        DatabaseManager.insertDocument(collection, stadium.getData());
    }
    
    public Stadium obtain(int id){
        HashMap<Object,Object> stadiumData = DatabaseManager.obtain(collection, id);
        String name = stadiumData.get("name").toString();
        double capacity = Double.parseDouble(stadiumData.get("capacity").toString());
        double boxmoney = Double.parseDouble(stadiumData.get("boxmoney").toString());

        return new Stadium(id, name, capacity, boxmoney);
    }
    
    public ArrayList<Stadium> obtainAll(){
        ArrayList<HashMap<Object,Object>> stadiumMaps = DatabaseManager.obtainAll(collection);
        
        ArrayList<Stadium> stadiums = new ArrayList<>();
                
        for(HashMap<Object,Object> map : stadiumMaps){
            
            String name = map.get("name").toString();
            int id = Integer.parseInt(map.get("id").toString());
            double capacity = Double.parseDouble(map.get("capacity").toString());
            double boxmoney = Double.parseDouble(map.get("boxmoney").toString());
            
            Stadium stadium = new Stadium(id, name, capacity, boxmoney);
            
            if(stadium != null){
                stadiums.add(stadium);
            }
        }
        return stadiums;
    }
}
