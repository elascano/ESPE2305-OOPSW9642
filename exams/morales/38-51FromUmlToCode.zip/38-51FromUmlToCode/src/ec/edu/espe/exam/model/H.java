
package ec.edu.espe.exam.model;

/**
 *
 * @author Anthony Morales, The_FAMSE
 */
public interface H {
    
}
